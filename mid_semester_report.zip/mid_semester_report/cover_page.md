# Nifty 50 Algorithmic Trading System
## Mid-Semester Report

Submitted by: [Student Name]
Roll Number: [Roll Number]

Supervisor: [Supervisor Name]
Department: [Department Name]
Institution: [Institution Name]

Date: [Current Date]